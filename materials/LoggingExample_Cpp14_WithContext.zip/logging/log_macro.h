#pragma once
#define LOG_INFO(code, ...) \
    gLogger->LogWithContext(__FILE__, __LINE__, __FUNCTION__, 1, code, ##__VA_ARGS__)