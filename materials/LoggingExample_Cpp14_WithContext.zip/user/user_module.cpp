#include "user_module.h"
#include "../logging/logging_adapter.h"

ILoggingAdapter* gLogger = nullptr;

void UserModuleFunction() {
    LOG_INFO(0x1001, "Disk failure");
    LOG_INFO(0x1002, "Running", "None");
}