// Empty translation unit for object file linking.
