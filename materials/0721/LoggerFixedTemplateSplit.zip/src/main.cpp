#include "ProductLogger.h"

ILogger* g_logger = nullptr;

#define DispatchReport(mode, code, ...) \
    if (g_logger) static_cast<ProductLogger*>(g_logger)->Report(code, ##__VA_ARGS__)

int main() {
    ProductLogger logger;
    g_logger = &logger;

    DispatchReport(false, 1001, "System", 85);   // Disk System full, usage 85%
    DispatchReport(false, 1002, "Alice", 42);    // User Alice not found at line 42
    DispatchReport(false, 9999);                 // Unknown error
    return 0;
}
