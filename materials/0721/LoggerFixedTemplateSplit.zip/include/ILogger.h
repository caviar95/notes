#pragma once

class ILogger {
public:
    virtual ~ILogger() = default;

    // 固定参数接口，用于支持 mock 和注入
    virtual int Report(int code) = 0;
};
