#pragma once
#include "ILogger.h"
#include "PlatformAPI.h"

class ProductLogger : public ILogger {
public:
    int Report(int code) override {
        return ReportError(false, code);  // 无参情况
    }

    // ✅ 仅在实现类定义模板函数（不放接口里）
    template <typename... Args>
    int Report(int code, Args&&... args) {
        return ReportError(false, code, std::forward<Args>(args)...);
    }
};
