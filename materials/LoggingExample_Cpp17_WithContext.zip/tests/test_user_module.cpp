#include <gtest/gtest.h>
#include "../logging/mock_adapter.h"
#include "../user/user_module.h"

TEST(UserModuleTest, LogWithContextWorks) {
    MockLoggingAdapter mock;
    gLogger = &mock;

    EXPECT_CALL(mock, LogVector(1, 0x1001, testing::Contains("Disk failure")));
    EXPECT_CALL(mock, LogVector(1, 0x1002, testing::Contains("Running")));

    UserModuleFunction();
}