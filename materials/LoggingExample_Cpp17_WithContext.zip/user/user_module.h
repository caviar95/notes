#pragma once
#include "../logging/log_macro.h"

class ILoggingAdapter;
extern ILoggingAdapter* gLogger;

void UserModuleFunction();